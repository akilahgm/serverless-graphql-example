const {externalMessage} = require('./deliveries/externalMessage')
const {getData} = require('./deliveries/getData')

module.exports = {
  externalMessage,
  getData
};